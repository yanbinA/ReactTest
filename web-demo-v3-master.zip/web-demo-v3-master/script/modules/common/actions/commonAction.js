/**
 * @file 公共Reflux Actoin
 * @author 崔健 cuijian03@baidu.com 2016.08.20
 */


var CommonAction = Reflux.createActions([
    // 切换轨迹管理台和设备管理台
    'switchtab'
]);

export default CommonAction